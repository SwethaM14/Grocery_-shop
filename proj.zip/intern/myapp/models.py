from django.db import models

class Userdata(models.Model):
    email = models.CharField(max_length=100)
    password = models.CharField(max_length=100)
    
    def __str__(self):
        return self.email

class Product(models.Model):
    name = models.CharField(max_length=200)
    image = models.ImageField(upload_to='product/')
    ogcost = models.IntegerField()
    discost = models.IntegerField()
    desc = models.TextField()

    def __str__(self):
        return self.name

class Cart(models.Model):
    user = models.ForeignKey(Userdata, on_delete=models.CASCADE)
    product = models.ForeignKey(Product, on_delete=models.CASCADE)
    quantity = models.PositiveIntegerField(default=1)

    def __str__(self):
        return self.product.name
