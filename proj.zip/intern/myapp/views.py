from django.shortcuts import render, redirect
from .models import Userdata, Product, Cart
from django.contrib import messages

def index(request):
    return render(request, 'index.html')

def login(request, method=['GET', 'POST']):
    if request.method == "POST":
        email = request.POST.get('email')
        password = request.POST.get('password')
        users = Userdata.objects.filter(email=email, password=password)

        if users.exists():
            request.session['email'] = email
            return redirect('/home/')
        else:
            return render(request, 'login.html')

    return render(request, 'login.html')

def signup(request, method=('GET', 'POST')):
    if request.method == "POST":
        email = request.POST.get('email')
        password = request.POST.get('password')
        password2 = request.POST.get('password2')

        user = Userdata.objects.filter(email=email)

        if user.exists():
            messages.info(request, "User already exists !!!")
        elif password != password2:
            messages.info(request, "Passwords do not match")
        else:
            Userdata.objects.create(email=email, password=password)
            return render(request, 'login.html')
    return render(request, 'signup.html')

def home(request):
    products = Product.objects.all()
    return render(request, "home.html", {"products": products})

def cart_page(request, id):
    email = request.session["email"]
    user = Userdata.objects.get(email=email)
    prod = Product.objects.get(id=id)

    cart_item, created = Cart.objects.get_or_create(user=user, product=prod)

    if not created:
        cart_item.quantity += 1
        cart_item.save()
    return redirect('/view_cart/')

def view_cart(request):
    email = request.session["email"]
    user = Userdata.objects.get(email=email)
    cart_items = Cart.objects.filter(user=user)
    total_prize = sum(item.product.discost * item.quantity for item in cart_items)  # lowercase `product`
    return render(request, 'cart.html', {'cart_items': cart_items, 'total_prize': total_prize})

def checkout(request):
    total = request.GET.get('total')
    return render(request, 'checkout.html', {'total': total})
